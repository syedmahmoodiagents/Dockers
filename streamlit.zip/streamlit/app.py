import streamlit as st
import requests

# Use the Docker service name as the hostname, NOT localhost
API_URL = "http://fastapi:8000"

def call_api(method: str, endpoint: str, payload: dict = None):
    """Generic API caller with error handling"""
    url = f"{API_URL}{endpoint}"
    try:
        if method == "GET":
            response = requests.get(url, timeout=10)
        elif method == "POST":
            response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()
        return response.json(), None
    except requests.exceptions.ConnectionError:
        return None, "Cannot connect to FastAPI service"
    except requests.exceptions.HTTPError as e:
        return None, f"HTTP Error: {e}"
    except Exception as e:
        return None, str(e)

# ---- UI ----
st.title("Streamlit + FastAPI in Docker")

# Health Check
if st.button("Check API Health"):
    data, err = call_api("GET", "/health")
    st.success(data) if data else st.error(err)

# GET items
if st.button("Fetch Items"):
    data, err = call_api("GET", "/items")
    st.json(data) if data else st.error(err)

# POST process
st.subheader("Process an Item")
name = st.text_input("Name", "banana")
value = st.number_input("Value", value=5)

if st.button("Send to FastAPI"):
    data, err = call_api("POST", "/process", {"name": name, "value": int(value)})
    st.json(data) if data else st.error(err)
