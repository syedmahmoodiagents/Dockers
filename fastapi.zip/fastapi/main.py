from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Item(BaseModel):
    name: str
    value: int

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/items")
def get_items():
    return {"items": ["apple", "banana", "cherry"]}

@app.post("/process")
def process(item: Item):
    return {"result": f"Processed: {item.name}", "doubled": item.value * 2}
